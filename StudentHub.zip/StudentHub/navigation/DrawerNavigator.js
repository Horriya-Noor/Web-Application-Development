import React from "react";
import { createDrawerNavigator } from "@react-navigation/drawer";

import StackNavigator from "./StackNavigator";
import SettingsScreen from "../screens/SettingsScreen";

const Drawer = createDrawerNavigator();

export default function DrawerNavigator({
  colors,
  isDark,
  setIsDark,
}) {
  return (
    <Drawer.Navigator
      screenOptions={{
        drawerStyle: {
          backgroundColor: colors.card,
        },
        drawerActiveTintColor: colors.primary,
        drawerInactiveTintColor: colors.secondaryText,
        headerStyle: {
          backgroundColor: colors.card,
        },
        headerTintColor: colors.text,
      }}
    >
      <Drawer.Screen
        name="Dashboard"
        options={{ title: "StudentHub" }}
      >
        {(props) => <StackNavigator {...props} colors={colors} />}
      </Drawer.Screen>

      <Drawer.Screen name="Settings">
        {(props) => (
          <SettingsScreen
            {...props}
            colors={colors}
            isDark={isDark}
            setIsDark={setIsDark}
          />
        )}
      </Drawer.Screen>
    </Drawer.Navigator>
  );
}