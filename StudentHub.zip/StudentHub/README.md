# StudentHub

A simple React Native / Expo student application demonstrating:

- Drawer Navigation
- Stack Navigation
- Bottom Tab Navigation
- Props
- useState
- Light/Dark Mode
- navigation.navigate()
- navigation.goBack()
- Reusable components
- Shared styling in ONE file

## Project Structure

StudentHub/
├── App.js
├── package.json
├── components/
│   ├── StudentCard.js
│   └── CourseCard.js
├── screens/
│   ├── HomeScreen.js
│   ├── CoursesScreen.js
│   ├── CourseDetailsScreen.js
│   ├── ProfileScreen.js
│   └── SettingsScreen.js
├── navigation/
│   ├── DrawerNavigator.js
│   ├── StackNavigator.js
│   └── TabNavigator.js
└── styles/
    └── styles.js

## Important

There is NO AssignmentsScreen.js and no Assignments option in the Drawer.

All common styling data is in:
styles/styles.js

## Install

Create an Expo project, then install:

npx expo install @react-navigation/native
npx expo install react-native-screens react-native-safe-area-context
npx expo install @react-navigation/native-stack
npx expo install @react-navigation/drawer
npx expo install react-native-gesture-handler react-native-reanimated
npx expo install @react-navigation/bottom-tabs
npx expo install @expo/vector-icons

Then replace the generated project files with these files.

Run:

npx expo start

## Navigation Flow

App.js
  |
  v
NavigationContainer
  |
  v
DrawerNavigator
  |
  +--> Dashboard
  |      |
  |      v
  |   StackNavigator
  |      |
  |      +--> MainTabs
  |      |     +--> Home
  |      |     +--> Courses
  |      |     +--> Profile
  |      |
  |      +--> CourseDetails
  |
  +--> Settings

## Viva Points

Props:
Values passed from a parent component to a child component.

useState:
Stores changing data, such as the Dark Mode state.

Drawer:
Side navigation menu.

Stack:
Screen-to-screen navigation where screens are placed in a stack.

Tabs:
Bottom navigation for the main sections.

navigate():
Moves to another screen.

goBack():
Returns to the previous screen.

Shared styles:
All common StyleSheet definitions are stored in styles/styles.js so the other files stay clean.
