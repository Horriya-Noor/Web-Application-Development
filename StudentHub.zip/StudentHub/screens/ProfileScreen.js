import React from "react";
import { View, Text } from "react-native";
import { commonStyles } from "../styles/styles";

export default function ProfileScreen({ colors }) {
  return (
    <View
      style={[
        commonStyles.screen,
        {
          backgroundColor: colors.background,
          alignItems: "center",
        },
      ]}
    >
      <View
        style={[
          commonStyles.profileCircle,
          { backgroundColor: colors.primary },
        ]}
      >
        <Text style={commonStyles.profileLetter}>A</Text>
      </View>

      <Text style={[commonStyles.heading, { color: colors.text }]}>
        Alex Student
      </Text>

      <Text style={[commonStyles.cardText, { color: colors.secondaryText }]}>
        Roll No: CS-101
      </Text>

      <Text style={[commonStyles.cardText, { color: colors.secondaryText }]}>
        Computer Science
      </Text>
    </View>
  );
}