import React from "react";
import { ScrollView, Text } from "react-native";
import CourseCard from "../components/CourseCard";
import { commonStyles } from "../styles/styles";

export default function CoursesScreen({ navigation, colors }) {
  const courses = [
    {
      id: "1",
      title: "Mobile Application Development",
      teacher: "Ms. Kausar",
      creditHours: 3,
    },
    {
      id: "2",
      title: "Database Systems",
      teacher: "Mr. Ahmed",
      creditHours: 3,
    },
    {
      id: "3",
      title: "Data Structures",
      teacher: "Dr. Ali",
      creditHours: 3,
    },
  ];

  return (
    <ScrollView
      style={{ backgroundColor: colors.background }}
      contentContainerStyle={commonStyles.scrollContent}
    >
      <Text style={[commonStyles.heading, { color: colors.text }]}>
        My Courses
      </Text>

      {courses.map((course) => (
        <CourseCard
          key={course.id}
          title={course.title}
          teacher={course.teacher}
          creditHours={course.creditHours}
          colors={colors}
          onPress={() =>
            navigation.navigate("CourseDetails", {
              courseName: course.title,
              teacher: course.teacher,
              creditHours: course.creditHours,
            })
          }
        />
      ))}
    </ScrollView>
  );
}