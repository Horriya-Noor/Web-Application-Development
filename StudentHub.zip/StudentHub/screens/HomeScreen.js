import React from "react";
import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import StudentCard from "../components/StudentCard";
import { commonStyles } from "../styles/styles";

export default function HomeScreen({ navigation, colors }) {
  return (
    <ScrollView
      style={{ backgroundColor: colors.background }}
      contentContainerStyle={commonStyles.scrollContent}
    >
      <Text style={[commonStyles.title, { color: colors.text }]}>
        Welcome to StudentHub
      </Text>

      <Text style={[commonStyles.subtitle, { color: colors.secondaryText }]}>
        Your simple student dashboard
      </Text>

      <StudentCard
        name="Alex Student"
        rollNo="CS-101"
        department="Computer Science"
        colors={colors}
      />

      <TouchableOpacity
        style={[commonStyles.button, { backgroundColor: colors.primary }]}
        onPress={() => navigation.navigate("Courses")}
      >
        <Text style={commonStyles.buttonText}>View Courses</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}