import React from "react";
import { TouchableOpacity, View, Text } from "react-native";
import { commonStyles } from "../styles/styles";

export default function CourseCard({
  title,
  teacher,
  creditHours,
  onPress,
  colors,
}) {
  return (
    <TouchableOpacity onPress={onPress}>
      <View
        style={[
          commonStyles.card,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <Text style={[commonStyles.cardTitle, { color: colors.text }]}>
          {title}
        </Text>

        <Text style={[commonStyles.cardText, { color: colors.secondaryText }]}>
          Teacher: {teacher}
        </Text>

        <Text style={[commonStyles.cardText, { color: colors.secondaryText }]}>
          Credit Hours: {creditHours}
        </Text>
      </View>
    </TouchableOpacity>
  );
}