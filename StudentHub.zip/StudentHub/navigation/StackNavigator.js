import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import TabNavigator from "./TabNavigator";
import CourseDetailsScreen from "../screens/CourseDetailsScreen";

const Stack = createNativeStackNavigator();

export default function StackNavigator({ colors }) {
  return (
    <Stack.Navigator>
      {/* Tabs are the main part of the app */}
      <Stack.Screen name="MainTabs" options={{ headerShown: false }}>
        {(props) => <TabNavigator {...props} colors={colors} />}
      </Stack.Screen>

      {/* Course details is opened from Courses */}
      <Stack.Screen
        name="CourseDetails"
        options={{
          title: "Course Details",
          headerStyle: {
            backgroundColor: colors.card,
          },
          headerTintColor: colors.text,
        }}
      >
        {(props) => (
          <CourseDetailsScreen {...props} colors={colors} />
        )}
      </Stack.Screen>
    </Stack.Navigator>
  );
}