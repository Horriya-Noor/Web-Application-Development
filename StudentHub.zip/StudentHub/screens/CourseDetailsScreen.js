import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { commonStyles } from "../styles/styles";

export default function CourseDetailsScreen({ navigation, route, colors }) {
  const { courseName, teacher, creditHours } = route.params;

  return (
    <View
      style={[
        commonStyles.screen,
        { backgroundColor: colors.background },
      ]}
    >
      <Text style={[commonStyles.heading, { color: colors.text }]}>
        Course Details
      </Text>

      <View
        style={[
          commonStyles.card,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <Text style={[commonStyles.cardTitle, { color: colors.text }]}>
          {courseName}
        </Text>

        <Text style={[commonStyles.cardText, { color: colors.text }]}>
          Teacher: {teacher}
        </Text>

        <Text style={[commonStyles.cardText, { color: colors.text }]}>
          Credit Hours: {creditHours}
        </Text>
      </View>

      <TouchableOpacity
        style={[
          commonStyles.backButton,
          { backgroundColor: colors.primary },
        ]}
        onPress={() => navigation.goBack()}
      >
        <Text style={commonStyles.buttonText}>Go Back</Text>
      </TouchableOpacity>
    </View>
  );
}