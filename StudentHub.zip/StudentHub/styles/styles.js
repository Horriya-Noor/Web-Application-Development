// =====================================================
// ALL STYLING DATA IS KEPT IN THIS ONE FILE.
// Screens and components only import styles from here.
// =====================================================

import { StyleSheet } from "react-native";

export const lightColors = {
  background: "#F5F7FB",
  card: "#FFFFFF",
  text: "#1E293B",
  secondaryText: "#64748B",
  primary: "#4F46E5",
  border: "#E2E8F0",
  white: "#FFFFFF",
  success: "#16A34A",
};

export const darkColors = {
  background: "#0F172A",
  card: "#1E293B",
  text: "#F8FAFC",
  secondaryText: "#CBD5E1",
  primary: "#818CF8",
  border: "#334155",
  white: "#FFFFFF",
  success: "#4ADE80",
};

export const getColors = (isDark) =>
  isDark ? darkColors : lightColors;

export const commonStyles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 20,
  },

  scrollContent: {
    padding: 20,
    paddingBottom: 30,
  },

  title: {
    fontSize: 28,
    fontWeight: "700",
    marginBottom: 8,
  },

  heading: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 10,
  },

  subtitle: {
    fontSize: 15,
    marginBottom: 20,
  },

  card: {
    borderRadius: 14,
    padding: 18,
    marginBottom: 15,
    borderWidth: 1,
  },

  cardTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 7,
  },

  cardText: {
    fontSize: 14,
    marginBottom: 5,
  },

  button: {
    borderRadius: 10,
    padding: 14,
    alignItems: "center",
    marginTop: 10,
  },

  buttonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "700",
  },

  backButton: {
    borderRadius: 10,
    padding: 14,
    alignItems: "center",
    marginTop: 10,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  profileCircle: {
    width: 85,
    height: 85,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 15,
  },

  profileLetter: {
    color: "#FFFFFF",
    fontSize: 32,
    fontWeight: "700",
  },

  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 18,
    borderBottomWidth: 1,
  },
});