import React from "react";
import { View, Text, Switch } from "react-native";
import { commonStyles } from "../styles/styles";

export default function SettingsScreen({
  isDark,
  setIsDark,
  colors,
}) {
  return (
    <View
      style={[
        commonStyles.screen,
        { backgroundColor: colors.background },
      ]}
    >
      <Text style={[commonStyles.heading, { color: colors.text }]}>
        Settings
      </Text>

      <View
        style={[
          commonStyles.settingRow,
          { borderBottomColor: colors.border },
        ]}
      >
        <View>
          <Text style={[commonStyles.cardTitle, { color: colors.text }]}>
            Dark Mode
          </Text>

          <Text
            style={[
              commonStyles.cardText,
              { color: colors.secondaryText },
            ]}
          >
            Change the app appearance
          </Text>
        </View>

        <Switch
          value={isDark}
          onValueChange={setIsDark}
          trackColor={{
            false: colors.border,
            true: colors.primary,
          }}
        />
      </View>
    </View>
  );
}