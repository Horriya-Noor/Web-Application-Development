import "react-native-gesture-handler";
import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import DrawerNavigator from "./navigation/DrawerNavigator";
import { getColors } from "./styles/styles";

export default function App() {
  // App-level state controls Light/Dark mode.
  const [isDark, setIsDark] = useState(false);

  // All color values come from one styling file.
  const colors = getColors(isDark);

  return (
    <NavigationContainer>
      <DrawerNavigator
        colors={colors}
        isDark={isDark}
        setIsDark={setIsDark}
      />
    </NavigationContainer>
  );
}