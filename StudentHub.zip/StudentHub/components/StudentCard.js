import React from "react";
import { View, Text } from "react-native";
import { commonStyles } from "../styles/styles";

export default function StudentCard({ name, rollNo, department, colors }) {
  return (
    <View
      style={[
        commonStyles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
        },
      ]}
    >
      <Text style={[commonStyles.cardTitle, { color: colors.text }]}>
        Student Information
      </Text>

      <Text style={[commonStyles.cardText, { color: colors.text }]}>
        Name: {name}
      </Text>

      <Text style={[commonStyles.cardText, { color: colors.text }]}>
        Roll No: {rollNo}
      </Text>

      <Text style={[commonStyles.cardText, { color: colors.text }]}>
        Department: {department}
      </Text>
    </View>
  );
}